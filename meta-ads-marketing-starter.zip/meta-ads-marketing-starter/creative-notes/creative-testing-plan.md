# Creative Testing Plan

| Concept ID | Format | Hook in first 3 seconds | Visual direction | Message | Status |
|---|---|---|---|---|---|
| C01 | 9:16 video | State the customer problem | Product demo | Benefit-led | Planned |
| C02 | 4:5 image | Lead with the offer | Product / lifestyle image | Offer-led | Planned |
| C03 | 9:16 video | Show before / after only when substantiated | Demonstration | Problem / solution | Planned |

## Review checklist
- [ ] Correct dimensions and safe zones
- [ ] Captions / subtitles checked
- [ ] Branding and CTA visible
- [ ] Claims and testimonials substantiated
- [ ] Music, footage, and image usage rights confirmed
- [ ] Feed and Stories / Reels previews checked
