# Meta Ads Marketing Starter

A simple, no-code GitHub repository for organizing Meta Ads campaign work.

## What this repository is for
Use it to keep campaign briefs, ad copy versions, creative notes, landing-page copy, and experiment results together. GitHub records each saved change (called a commit), so you can review what changed and why.

## Folder guide
- `campaign-brief/` — objective, audience, offer, budget, and KPIs
- `ad-copy/` — primary text, headlines, descriptions, and CTAs
- `creative-notes/` — image/video concepts and production notes
- `landing-page/` — page copy and change notes
- `reports/` — weekly performance summaries
- `experiments/` — test plans and results

## First steps
1. Create a new repository on https://github.com/new
2. Name it `meta-ads-marketing-playbook`.
3. Choose **Public** only if you are comfortable sharing the contents; otherwise choose **Private**.
4. Upload these files using **Add file → Upload files**.
5. In the commit message, write what you added, for example: `Add initial Meta campaign templates`.
6. When you update a file, upload the revised version and use a clear commit message, such as `Test shorter headline for prospecting ad`.

## Important
Do not upload customer personal data, passwords, access tokens, private ad account information, or confidential client reports. Remove or anonymize sensitive data before sharing.
