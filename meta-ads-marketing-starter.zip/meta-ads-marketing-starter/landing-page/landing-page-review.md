# Landing Page Review

- Page URL:
- Campaign:
- Review date:
- Mobile load and layout:
- Message matches the ad:
- Main headline:
- Primary CTA:
- Form / checkout tested:
- Trust signals:
- Privacy notice and consent:
- Issues to fix:
- Owner and due date:
