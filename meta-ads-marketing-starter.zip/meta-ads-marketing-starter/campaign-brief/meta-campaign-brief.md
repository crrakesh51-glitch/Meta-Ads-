# Meta Ads Campaign Brief

## Campaign details
- Brand / product:
- Campaign name:
- Campaign owner:
- Start and end dates:
- Objective: Awareness / Traffic / Leads / Sales
- Destination: Website / Instant Form / WhatsApp / App

## Audience
- Location:
- Age range:
- Audience type: Broad / Interest / Custom / Lookalike
- Exclusions:

## Offer and message
- Main offer:
- Customer problem:
- Key benefit:
- Proof point:
- Primary CTA:

## Budget and KPIs
- Daily or lifetime budget:
- KPI: CPM / CTR / CPC / CPL / CPA / ROAS
- Target:
- Reporting frequency:

## Tracking and checks
- Pixel / Dataset event:
- UTM naming:
- Landing page tested:
- Mobile preview checked:
- Policy and claims reviewed:
