# Meta Ads Experiment Log

| Test ID | Hypothesis | Variable changed | Audience / setup | Primary metric | Start date | End date | Outcome / decision |
|---|---|---|---|---|---|---|---|
| T01 | A shorter headline may improve CTR | Headline | Keep other settings consistent | Link CTR | YYYY-MM-DD | YYYY-MM-DD | Pending |

## Testing notes
- Change one major variable at a time where practical.
- Define the primary metric before launch.
- Avoid declaring a winner from very small or uneven samples.
- Record budget, dates, attribution settings, and any delivery changes.
