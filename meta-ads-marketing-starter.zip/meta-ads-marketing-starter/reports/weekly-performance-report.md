# Weekly Meta Ads Performance

- Week:
- Account / campaign:
- Objective:
- Spend:
- Impressions:
- Reach:
- Link clicks:
- Link CTR:
- CPC:
- Leads / purchases:
- CPL / CPA:
- Revenue:
- ROAS:

## What changed this week
-

## What worked
-

## What did not work
-

## Next actions
1.
2.
3.

*Use the same attribution window and reporting definitions when comparing periods.*
